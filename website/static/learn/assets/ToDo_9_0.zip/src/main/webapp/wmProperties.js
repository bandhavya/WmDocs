var _WM_APP_PROPERTIES = {
  "activeTheme" : "mobile",
  "defaultLanguage" : "en",
  "displayName" : "ToDo-9.0",
  "homePage" : "Main",
  "name" : "ToDo_9_0",
  "platformType" : "MOBILE",
  "securityEnabled" : "true",
  "supportedLanguages" : "en",
  "type" : "APPLICATION",
  "version" : "1.0"
};